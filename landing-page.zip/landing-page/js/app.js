/**
 *
 * Manipulating the DOM exercise.
 * Exercise programmatically builds navigation,
 * scrolls to anchors from navigation,
 * and highlights section in viewport upon scrolling.
 *
 * Dependencies: None
 *
 * JS Version: ES2015/ES6
 *
 * JS Standard: ESlint
 *
 */



// Declare a variable contain all the section that exist in the page using querySelectorAll method
const sections = document.querySelectorAll('section');
// get the navbar unOrderlist using getElementById and assign it to a variable called a getLiContainer
const getLiContainer = document.getElementById('navbar__list');


// we can loop using forEach or for loop or even for of and  I will use for loop here I'm more comfortable with it 
for (let i = 0; i < sections.length; i++) {
    // build the nav

    // create li elment and declare a varible and put it inside of createdLiItmes
    const createLiItmes = document.createElement('li');
    // apend the li inside navbar and assign it to a value 
    const liContainer = getLiContainer.appendChild(createLiItmes);
    //create anchor tag <a>
    const createAnchorTags = document.createElement('a');
    // then append the a tag into the li tag then create a variable to put the created li with anchor inside
    const proSections = createLiItmes.appendChild(createAnchorTags);
    //finally put the anchor tag inside the navbarlist using appendchild 
    liContainer.appendChild(proSections);
    //then change the inner html by using .innerHTML/ or Text content

    proSections.innerHTML = sections[i].getAttribute('data-nav');
    // I was using this insted of the above one it works but to make it more clean I used getAttribute method to get the text form the sections 
    // proSections.textContent =  section${i + 1} 
    //then I add a click event on the links/anchors 

    createAnchorTags.addEventListener("click", function () {

        // I take this scrollIntoView method form MDN because we didn't take it in the udacity lesson 
        // Scroll to section on link click  

        sections[i].scrollIntoView({
            behavior: "smooth",
            block: "end",
            inline: "nearest"
        });

    })
}

// Add class 'active' to section when near top of viewport

window.addEventListener("scroll", function () {


    //get all the ahchors that exist on the page by using querySelectorAll method 
    const getAnchors = document.querySelectorAll('a');

    for (let i = 0; i < sections.length; i++) {

        //I take  a hint about getBoundingClientReact()  form discourse tutor and MDN then I do it with myself like this  
        // create a vaiable and assign it to the value of the top value of the section in the viewport
        const getTopValue = (sections[i].getBoundingClientRect().top);
        // Set sections as active if it is in the viewport by using if else condition 
        if (getTopValue >= -50 && getTopValue <= 300) {
            // check if the section  has the active class or not and if not add it to the section and the link to make the highlight 
            if (sections[i].classList.contains('your-active-class') === false) {
                sections[i].classList.add('your-active-class');
                getAnchors[i].classList.add('menu__link');
            }

        } else {
            //remove the active class if section and the anchors isn't in the viewport
            sections[i].classList.remove('your-active-class');
            getAnchors[i].classList.remove('menu__link');

        }
    }
})