# Landing Page Project



## Table of Contents
  - [Landing Page Project](#landing-page-project)
  - [Introuduction](#introuduction)
  - [Table of Contents](#table-of-contents)
  - [Instructions](#instructions)
  - [Project Parts](#project-parts)
    - [First Part](#first-part)
    - [Second Part](#second-part)
    - [About Me](#about-me)




## Introuduction
This project converst a static HTML and CSS landing page into a dynamic one by the help  the DOM Mannpulation that I learned by Udacity Classroom to add the functiounality the page I crearted a dynamic nav bar and add links/anchors dynamically inside it when you click a link it take you to the sectioon that you wanted then when you scroll you will find a nice effect by ading a class when you are on the section and remove it when you aren't on that section 

## Instructions
## Project Parts 
### First Part
I added a script tage inside the HTML file to connect tha js file  with HTML file in the starter files of the prject
```
<script src="js/app.js"></script>
```
That was the easiest one in the project so let's go the next parts all the work is there
besides I adjust the HTML files and add more sections to test my code and changed the css because the text was white in the nav bar and add some padding 
### Second Part

**Creating the nav-bar** was the first step that  make me get into ths project It help me to undrestand the prjoct 
1. I get all the sections in the page using QuerySelectorAll() method and assign it to a variable and I called it **sections**
2. I catch the unorderList using getElementById() method and assign it to a variable called **getLiContainer** we will use it some after the next step
3. then I use a for loop to get every section alone to add the click event in it 
   * but before that I had to create the nav menu items I did that using a  lot of setps  I wil explain it here 

4. I created a list using createElement() method and assing it to a variable called **createLiItmes**       
5. I append this list the ul tag so I have  no a ```<li>``` inside of ```ul``` 
6. then I create the anchors tag and assing it to varibel called **createAnchorTags**
7. then I append the **createAnchorTags** inside the **liContainer** 
   
      * now we have the ```<ul><li> <a></a></li></ul>``` so what next we need to add the inner the to the name of the section and we have a lot of ways to do that using temeplate string or use the data-nav attribute 
8. I created a lot of variable to make append elments easy for me so I changed the innerHTML for every ```<a>``` using the getAttribute() methods ```proSections.innerHTML = sections[i].getAttribute('data-nav') ``` even I tried this and It works too ``` proSections.textContent =  section${i + 1}```
    * so now we build the nav menu now we need the add the click event 

9. I add the the cick event on the **createAnchorTags** and used the addEventListener() methods after I read the MDN article about it 
   * To be honest I did a lot of tries and failed a lot to did that point because I put every thing in the loop because of the local scope problem but I just comment them if I want to use them later

10. then I reached a vital part of the project and without the help of MDN I wouldn't write this part ``` sections[i].scrollIntoView({ behavior: "smooth", block: "end", inline: "nearest" }); ``` 
   * Amazing now we have the nav bar menu and It's dynamic and when we click at it . it take us to the right secntion so what's next alright we need to add the active class when we click the anchor or scroll to the section that we want Ok the job almost done
11. This part was the hardest step in all the project but I jus missed how to do it in the begining and did with the click event not the scroll so let's finish our project 
12. I added a addEventListner to the window object and add a scroll event 
    * I did that step ine with the click event in the first addEventListner but It wasn't good practice so I move it to a spearte code and that is the rigth witout that it will not work
13. then I get all the anchors using querySelectorAll() and assing them to a variable called  **getAnchors** 
14. then we nee a loop over the section or the links I did on the section ``` for (let i = 0; i < sections.length; i++) {...} ```

15. now after create the for loop we need the check if there is an active class in the section or not beside if there is a one in the anchors too 
16. but before that we need to check if that section is in the viewport or not and here we can use **Intersection Observer API** or **getBoundingClientRect()**  I used here the last one after I understand it and how it works then I understand after print its value in the console that I need the top or y value then I assing that to a variable called **getTopValue** 
  ```const getTopValue = (sections[i].getBoundingClientRect().top);```  
17. then I will check this value by using **if else** condition  to check if the section is is in the view port  and if it has an active class or not actually I used a **nested if** and that was the masterpiece of the project because I combined all the adding of the classes inside of it 
18. I will expain this in more detail even I did that in the comment but no problem I make a if condtion to see if the section or the **getTopValue** to check  if it's in the viewport or not  by using ```(getTopValue >= -50 && getTopValue <= 300)  ```and to see if the section has an active class or not if it hasnt' then add an active class to the section and to the anchors and if if  it's not in the viewport delete the active class That's it that my first project I 'm so excited that I finihsed it with my own amazing feeling 
 
    



### About Me
I'm **Khalid Reda Abel Aziz** I want to be full time freelancer or work full time remotely within a _year_ form now as  _junior Front-End Deverloper/React Developer_